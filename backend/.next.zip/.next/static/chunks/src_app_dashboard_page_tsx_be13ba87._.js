(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_f240f67a._.js",
  "static/chunks/node_modules_recharts_es6_8235043b._.js",
  "static/chunks/node_modules_1b46d93c._.js",
  "static/chunks/src_006709bd._.js"
],
    source: "dynamic"
});
