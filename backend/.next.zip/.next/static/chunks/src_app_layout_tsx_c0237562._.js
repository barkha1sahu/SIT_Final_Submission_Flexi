(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3d823d1a._.js",
  "static/chunks/src_1246dabe._.js",
  "static/chunks/src_app_globals_b805903d.css"
],
    source: "dynamic"
});
